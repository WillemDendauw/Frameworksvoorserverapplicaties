package iii.jpaproject.vbjpa.model;

public class MyFactory {
    //Methodes om objecten aan te maken
    public static Land maakLand(String naam){
        Land l = new Land();
        l.setNaam(naam);
        return l;
    }
    
    public static Hoofdstad maakHoofdstad(String naam, int bevolkingsaantal){
        Hoofdstad h = new Hoofdstad();
        h.setNaam_hoofdstad(naam);
        h.setBevolkingsaantal_hoofdstad(bevolkingsaantal);
        return h;
    }
    
    public static Staatshoofd maakStaatshoofd(String naam, String functie){
        Staatshoofd s = new Staatshoofd();
        s.setNaam(naam);
        s.setFunctie(functie);
        return s;
    }
    
    public static Inwoner maakInwoner(String naam, String kenmerk){
        Inwoner i = new Inwoner();
        i.setNaam(naam);
        i.setKenmerk(kenmerk);
        return i;
    }
    
    public static Taal maakTaal(String naam){
        Taal t = new Taal();
        t.setNaam(naam);
        return t;
    }
    
    //Methodes om relaties vast te leggen
    public static void stelHoofdstadInVanLand(Land l, Hoofdstad h){
        l.setHoofdstad(h);
    }
    
    public static void stelStaatshoofdInVanLand(Land l, Staatshoofd s){
        l.setStaatshoofd(s);
        s.setLand(l);      
    }
    
    public static void stelLandInVanInwoner(Land l, Inwoner i){
        i.setLand(l);
    }
    
    public static void stelTaalInVanLand(Land l, Taal t){
        l.getTalen().add(t);
        t.getLanden().add(l);
    } 
}
