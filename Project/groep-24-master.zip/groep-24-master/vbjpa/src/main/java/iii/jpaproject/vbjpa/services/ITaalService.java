package iii.jpaproject.vbjpa.services;

import iii.jpaproject.vbjpa.model.Taal;
import java.util.List;

public interface ITaalService {
    
    List<Taal> getAllTalen();

    List<Taal> getAllTalenByNaam(String naam);

    Taal getTaalById(Long id);
    
    boolean addTaal(Taal t);

    void deleteTaal(Long id);

    void updateTaal(Taal t); 
}
