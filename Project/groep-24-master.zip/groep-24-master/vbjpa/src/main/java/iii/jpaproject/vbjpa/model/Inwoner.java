package iii.jpaproject.vbjpa.model;

import javax.persistence.*;

@Entity
@Table(name = "inwoner")
@PrimaryKeyJoinColumn(name = "P_ID")
public class Inwoner extends Persoon{   
    private String kenmerk;
    private Land land;
    
    public Inwoner() {
    }
    
    //GETTERS
    @Basic
    public String getKenmerk() {
        return kenmerk;
    }
    
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name = "L_ID")
    public Land getLand() {
        return land;
    }
    
    //SETTERS
    public void setLand(Land land) {
        this.land = land;
    }
    
    public void setKenmerk(String kenmerk) {
        this.kenmerk = kenmerk;
    }
}
