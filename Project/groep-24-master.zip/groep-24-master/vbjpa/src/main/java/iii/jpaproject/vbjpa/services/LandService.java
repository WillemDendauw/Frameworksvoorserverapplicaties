package iii.jpaproject.vbjpa.services;

import iii.jpaproject.vbjpa.model.Land;
import iii.jpaproject.vbjpa.repositories.LandRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LandService implements ILandService {
    @Autowired
    private LandRepository landRepo;
    
    @Override
    public List<Land> getAllLanden(){
        List<Land> landen = new ArrayList<>();
        for(Land l : landRepo.findAll()){
            landen.add(l);
        }
        return landen;
    }
    
    @Override
    public List<Land> getAllLandenByNaam(String naam){
        List<Land> landen = landRepo.findByNaam(naam);
        return landen;
    }
    
    @Override
    public Land getLandById(Long id){
        return landRepo.findById(id).get();
    }
    
    @Override
    public boolean addLand(Land l){
        List<Land> list = landRepo.findByNaam(l.getNaam());
        if (list.size() > 0) {
    	    return false;
        } else {
    	    landRepo.save(l);
    	    return true;
        }
    }
    
    @Override
    public void deleteLand(Long id){
        landRepo.deleteById(id);
    }
    
    @Override
    public void updateLand(Land l){
        landRepo.save(l);
    }
}
