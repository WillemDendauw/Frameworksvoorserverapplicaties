package iii.jpaproject.vbjpa.model;

import java.io.Serializable;
import javax.persistence.Embeddable;

@Embeddable
public class Hoofdstad implements Serializable {    
    private String naam_hoofdstad;
    private int bevolkingsaantal_hoofdstad;
    
    public Hoofdstad() {     
    }
    
    //GETTERS
    public String getNaam_hoofdstad() {
        return naam_hoofdstad;
    }

    public int getBevolkingsaantal_hoofdstad() {
        return bevolkingsaantal_hoofdstad;
    }
    
    //SETTERS
    public void setNaam_hoofdstad(String naam_hoofdstad) {
        this.naam_hoofdstad = naam_hoofdstad;
    }

    public void setBevolkingsaantal_hoofdstad(int bevolkingsaantal_hoofdstad) {
        this.bevolkingsaantal_hoofdstad = bevolkingsaantal_hoofdstad;
    }
}
