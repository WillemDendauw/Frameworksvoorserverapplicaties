package iii.jpaproject.vbjpa.model;

import javax.persistence.*;

@Entity
@Table(name = "staatshoofd")
@PrimaryKeyJoinColumn(name = "P_ID")
public class Staatshoofd extends Persoon{ 
    private Long id;
    private String functie;
    private Land land;
    
    
    public Staatshoofd() {
    }
    
    //GETTERS
    @Id()
    @GeneratedValue (strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }
    
    @Basic
    public String getFunctie() {
        return functie;
    }
    
    @OneToOne(optional = false, fetch=FetchType.LAZY)
    @JoinColumn(name = "L_ID", unique = true, nullable = false, updatable = false)
    public Land getLand() {
        return land;
    }
    
    //SETTERS
    private void setId(Long id) {
        this.id = id;
    }

    public void setFunctie(String functie) {
        this.functie = functie;
    }

    public void setLand(Land land) {
        this.land = land;
    }  
}
