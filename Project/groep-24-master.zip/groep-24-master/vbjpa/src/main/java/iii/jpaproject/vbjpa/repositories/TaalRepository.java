package iii.jpaproject.vbjpa.repositories;

import iii.jpaproject.vbjpa.model.Taal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TaalRepository extends JpaRepository<Taal, Long> {
    List<Taal> findByNaam(String naam);
}
