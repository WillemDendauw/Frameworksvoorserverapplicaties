package iii.jpaproject.vbjpa.services;

import iii.jpaproject.vbjpa.model.Taal;
import iii.jpaproject.vbjpa.repositories.TaalRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaalService implements ITaalService {   
    @Autowired
    private TaalRepository taalRepo;
    
    @Override
    public List<Taal> getAllTalen(){
        List<Taal> talen = new ArrayList<>();
        for(Taal t : taalRepo.findAll()){
            talen.add(t);
        }
        return talen;
    }
    
    @Override
    public List<Taal> getAllTalenByNaam(String naam){
        List<Taal> talen = taalRepo.findByNaam(naam);
        return talen;
    }
    
    @Override
    public Taal getTaalById(Long id){
        return taalRepo.findById(id).get();
    }
    
    @Override
    public boolean addTaal(Taal t){
        List<Taal> list = taalRepo.findByNaam(t.getNaam());
        if (list.size() > 0) {
    	    return false;
        } else {
    	    taalRepo.save(t);
    	    return true;
        }
    }
    
    @Override
    public void deleteTaal(Long id){
        taalRepo.deleteById(id);
    }  
    
    @Override
    public void updateTaal(Taal t){
        taalRepo.save(t);
    }
}
