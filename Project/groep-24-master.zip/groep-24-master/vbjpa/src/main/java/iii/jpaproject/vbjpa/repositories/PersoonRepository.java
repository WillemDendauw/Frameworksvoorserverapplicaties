package iii.jpaproject.vbjpa.repositories;

import iii.jpaproject.vbjpa.model.Persoon;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface PersoonRepository<T extends Persoon> extends JpaRepository<T, Long> {
    List<Persoon> findByNaam(String naam);
}
