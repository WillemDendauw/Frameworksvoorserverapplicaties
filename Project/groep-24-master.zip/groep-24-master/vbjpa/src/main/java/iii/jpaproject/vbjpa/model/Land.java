package iii.jpaproject.vbjpa.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name = "land")
public class Land implements Serializable {   
    private Long id;
    private String naam;
    private Staatshoofd staatshoofd;
    private Hoofdstad hoofdstad;
    private List<Taal> talen = new ArrayList<>();

    public Land() {
    }

    //GETTERS
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }
    
    @Basic
    public String getNaam() {
        return naam;
    }
    
    @OneToOne(mappedBy="land", fetch=FetchType.EAGER, cascade = CascadeType.ALL)
    public Staatshoofd getStaatshoofd() {
        return staatshoofd;
    }

    @Embedded
    public Hoofdstad getHoofdstad() {
        return hoofdstad;
    }
    
    @ManyToMany(fetch=FetchType.LAZY)
    @JoinTable(name = "taalgebruik",
            joinColumns=@JoinColumn(name="Land"),
            inverseJoinColumns=@JoinColumn(name="Taal"))
    public List<Taal> getTalen() {
        return talen;
    }

    //SETTERS
    private void setId(Long id) {
        this.id = id;
    }
    
    public void setNaam(String naam) {
        this.naam = naam;
    }
    
    public void setStaatshoofd(Staatshoofd staatshoofd) {
        this.staatshoofd = staatshoofd;
    }
    
    public void setHoofdstad(Hoofdstad hoofdstad) {
        this.hoofdstad = hoofdstad;
    }

    public void setTalen(List<Taal> talen) {
        this.talen = talen;
    }
}
