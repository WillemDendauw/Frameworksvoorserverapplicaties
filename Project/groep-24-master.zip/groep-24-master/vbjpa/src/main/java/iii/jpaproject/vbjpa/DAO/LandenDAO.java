package iii.jpaproject.vbjpa.DAO;

import iii.jpaproject.vbjpa.model.Inwoner;
import iii.jpaproject.vbjpa.model.Land;
import iii.jpaproject.vbjpa.model.MyFactory;
import iii.jpaproject.vbjpa.model.Persoon;
import iii.jpaproject.vbjpa.model.Staatshoofd;
import iii.jpaproject.vbjpa.model.Taal;
import iii.jpaproject.vbjpa.services.LandService;
import iii.jpaproject.vbjpa.services.PersoonService;
import iii.jpaproject.vbjpa.services.TaalService;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LandenDAO {
    
    @Autowired
    private TaalService taalServ;
    
    @Autowired
    private PersoonService persServ;
    
    @Autowired
    private LandService landServ;
    
    public LandenDAO() {
    }
    
    //Methodes Persoon
    public List<Persoon> getAllPersonen(){
        return persServ.getAllPersonen();
    }
    
    public List<Persoon> getAllPersonenByNaam(String naam){
        return persServ.getAllPersonenByNaam(naam);
    }
    
    public List<Inwoner> getAllInwoners(){
        return persServ.getAllInwoners();
    }
    
    public List<Inwoner> getAllInwonersByKenmerk(String kenmerk){
        return persServ.getAllInwonersByKenmerk(kenmerk);
    }
    
    public Inwoner getInwonerById(Long id){
        return persServ.getInwonerById(id);
    }
    
    public List<Staatshoofd> getAllStaatshoofden(){
        return persServ.getAllStaatshoofden();
    }
    
    public List<Staatshoofd> getAllStaatshoofdenByFunctie(String functie){
        return persServ.getAllStaatshoofdenByFunctie(functie);
    }
    
    public Staatshoofd getStaatshoofdById(Long id){
        return persServ.getStaatshoofdById(id);
    }
    
    public boolean addInwoner(Inwoner i){
        return persServ.addInwoner(i);
    }
    
    public boolean addInwoners(Collection<Inwoner> inwoners){
        Iterator<Inwoner> iterator = inwoners.iterator();
        while (iterator.hasNext()) {
            persServ.addInwoner(iterator.next());
        }
        return true;
    }
    
    public boolean addStaatshoofd(Staatshoofd s){
        return persServ.addStaatshoofd(s);
    }
    
    public void deleteInwonerById(Long id){
        persServ.deleteInwoner(id);
    }
    
    public void deleteStaatshoofdById(Long id){
        persServ.deleteStaatshoofd(id);
    }
    
    public void updateInwoner(Long id, Inwoner i){
       Inwoner origineel = persServ.getInwonerById(id);
       origineel.setNaam(i.getNaam());
       origineel.setKenmerk(i.getKenmerk());
       origineel.setLand(i.getLand());
       persServ.updateInwoner(origineel);
    }
    
    public void updateStaatshoofd(Long id, Staatshoofd s){
       Staatshoofd origineel = persServ.getStaatshoofdById(id);
       origineel.setNaam(s.getNaam());
       origineel.setFunctie(s.getFunctie());
       origineel.setLand(s.getLand());
       persServ.updateStaatshoofd(origineel);
    }
    
    //Methodes Taal
    public List<Taal> getAllTalen(){
        return taalServ.getAllTalen();
    }
    
    public List<Taal> getAllTalenByNaam(String naam){
        return taalServ.getAllTalenByNaam(naam);
    }
    
    public Taal getTaalByID(Long id){
        return taalServ.getTaalById(id);
    }
    
    public boolean addTaal(Taal t){
        return taalServ.addTaal(t);
    }
    
    public boolean addTalen(Collection<Taal> talen){
        Iterator<Taal> iterator = talen.iterator();
        while (iterator.hasNext()) {
            taalServ.addTaal(iterator.next());
        }
        return true;
    }
    
    public void deleteTaalById(Long id){
        taalServ.deleteTaal(id);
    }
    
    public void updateTaal(Long id, Taal t){
        Taal origineel = taalServ.getTaalById(id);
        origineel.setNaam(t.getNaam());
        origineel.setLanden(new ArrayList<>());
        for(Land l : t.getLanden()){
            origineel.getLanden().add(l);
            MyFactory.stelTaalInVanLand(l, origineel);
        }
        taalServ.updateTaal(origineel);
    }
       
    //Methodes Land
    public List<Land> getAllLanden(){
        return landServ.getAllLanden();
    }
    
    public List<Land> getAllLandenByNaam(String naam){
        return landServ.getAllLandenByNaam(naam);
    }
    
    public Land getLandById(Long id){
        return landServ.getLandById(id);
    }
    
    public boolean addLand(Land l){
        return landServ.addLand(l);
    }
    
    public void deleteLandById(Long id){
        landServ.deleteLand(id);
    }
    
    public void updateLand(Long id, Land l){
        Land origineel = landServ.getLandById(id);     
        origineel.setNaam(l.getNaam());
        origineel.setHoofdstad(l.getHoofdstad());
        origineel.getStaatshoofd().setFunctie(l.getStaatshoofd().getFunctie());
        origineel.getStaatshoofd().setNaam(l.getStaatshoofd().getNaam());
        MyFactory.stelHoofdstadInVanLand(origineel, l.getHoofdstad());   
        origineel.setTalen(new ArrayList<>());          
        for(Taal t : l.getTalen()){
            origineel.getTalen().add(t);
            MyFactory.stelTaalInVanLand(origineel, t);
        }
        landServ.updateLand(origineel);
    }  
}
