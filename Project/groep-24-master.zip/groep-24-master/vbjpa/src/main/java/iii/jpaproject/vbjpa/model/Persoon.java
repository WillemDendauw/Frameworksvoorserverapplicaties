package iii.jpaproject.vbjpa.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "persoon")
@Inheritance(strategy = InheritanceType.JOINED)
public class Persoon implements Serializable {
    private Long id;
    private String naam;
    
    public Persoon() {
    }
    
    //GETTERS
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }
    
    @Basic
    public String getNaam() {
        return naam;
    }
    
    //SETTERS
    private void setId(Long id) {
        this.id = id;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    } 
}
