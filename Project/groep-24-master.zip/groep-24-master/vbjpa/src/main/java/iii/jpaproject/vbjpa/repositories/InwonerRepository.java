package iii.jpaproject.vbjpa.repositories;

import iii.jpaproject.vbjpa.model.Inwoner;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InwonerRepository extends PersoonRepository<Inwoner>, JpaRepository<Inwoner, Long>{
    List<Inwoner> findByKenmerk(String kenmerk);   
}
