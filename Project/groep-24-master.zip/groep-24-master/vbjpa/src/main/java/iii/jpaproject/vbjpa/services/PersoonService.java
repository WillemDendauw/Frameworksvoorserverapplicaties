package iii.jpaproject.vbjpa.services;

import iii.jpaproject.vbjpa.model.Inwoner;
import iii.jpaproject.vbjpa.model.Persoon;
import iii.jpaproject.vbjpa.model.Staatshoofd;
import iii.jpaproject.vbjpa.repositories.InwonerRepository;
import iii.jpaproject.vbjpa.repositories.StaatshoofdRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersoonService implements IPersoonService {
    @Autowired
    private InwonerRepository inwonerRepo;
    
    @Autowired
    private StaatshoofdRepository staatshoofdRepo;
    
    @Override
    public List<Persoon> getAllPersonen(){
        List<Persoon> res = new ArrayList<>();
        for(Inwoner i : inwonerRepo.findAll()){
            res.add(i);
        }
        for(Staatshoofd s : staatshoofdRepo.findAll()){
            res.add(s);
        }
        return res;
    }  
    
    @Override
    public List<Persoon> getAllPersonenByNaam(String naam){
        List<Persoon> pers = new ArrayList<>();
        for(Persoon i : inwonerRepo.findByNaam(naam)){
            pers.add(i);
        }
        for(Persoon s : staatshoofdRepo.findByNaam(naam)){
            pers.add(s);
        }
        return pers;
    }
    
    @Override
    public List<Inwoner> getAllInwoners(){
        List<Inwoner> inw = new ArrayList<>();
        for(Inwoner i : inwonerRepo.findAll()){
            inw.add(i);
        }
        return inw;
    }
    
    @Override
    public List<Inwoner> getAllInwonersByKenmerk(String kenmerk){
        List<Inwoner> inw = inwonerRepo.findByKenmerk(kenmerk);
        return inw;
    }
    
    @Override
    public Inwoner getInwonerById(Long id){
        return inwonerRepo.findById(id).get();
    }
    
    @Override
    public List<Staatshoofd> getAllStaatshoofden(){
        List<Staatshoofd> sh = new ArrayList<>();
        for(Staatshoofd s : staatshoofdRepo.findAll()){
            sh.add(s);
        }
        return sh;
    }
    
    @Override
    public List<Staatshoofd> getAllStaatshoofdenByFunctie(String functie){
        List<Staatshoofd> sth = staatshoofdRepo.findByFunctie(functie);
        return sth;
    }
    
    @Override
    public Staatshoofd getStaatshoofdById(Long id){
        return staatshoofdRepo.findById(id).get();
    }
    
    @Override
    public boolean addInwoner(Inwoner i){
        List<Persoon> list = inwonerRepo.findByNaam(i.getNaam());
        if (list.size() > 0) {
    	    return false;
        } else {
    	    inwonerRepo.save(i);
    	    return true;
        }
    }
    
    @Override
    public boolean addStaatshoofd(Staatshoofd s){
        List<Persoon> list = staatshoofdRepo.findByNaam(s.getNaam());
        if (list.size() > 0) {
    	    return false;
        } else {
    	    staatshoofdRepo.save(s);
    	    return true;
        }
    }
    
    @Override
    public void deleteInwoner(Long id){
        inwonerRepo.deleteById(id);
    }
    
    @Override
    public void deleteStaatshoofd(Long id){
        staatshoofdRepo.deleteById(id);
    }
    
    @Override
    public void updateInwoner(Inwoner i){
        inwonerRepo.save(i);
    }
    
    @Override
    public void updateStaatshoofd(Staatshoofd s){
        staatshoofdRepo.save(s);
    }  
}
