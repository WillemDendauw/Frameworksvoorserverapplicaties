package iii.jpaproject.vbjpa.services;

import iii.jpaproject.vbjpa.model.Land;
import java.util.List;

public interface ILandService {
    
    List<Land> getAllLanden();

    List<Land> getAllLandenByNaam(String naam);
    
    Land getLandById(Long id);

    boolean addLand(Land l);

    void deleteLand(Long id);

    void updateLand(Land l);  
}
