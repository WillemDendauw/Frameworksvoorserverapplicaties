package iii.jpaproject.vbjpa.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name="taal")
public class Taal implements Serializable {   
    private Long id;
    private String naam;
    private List<Land> landen = new ArrayList<>();

    public Taal() {
    }
    
    //GETTERS
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    @Basic
    public String getNaam() {
        return naam;
    }
    
    @ManyToMany(mappedBy="talen", fetch=FetchType.EAGER)
    public List<Land> getLanden() {
        return landen;
    }
    
    //SETTERS
    private void setId(Long id) {
        this.id = id;
    }
    
    public void setNaam(String naam) {
        this.naam = naam;
    }

    public void setLanden(List<Land> landen) {
        this.landen = landen;
    }
}
