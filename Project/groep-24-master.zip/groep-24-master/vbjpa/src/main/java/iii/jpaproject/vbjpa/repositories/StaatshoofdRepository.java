package iii.jpaproject.vbjpa.repositories;

import iii.jpaproject.vbjpa.model.Staatshoofd;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StaatshoofdRepository extends PersoonRepository<Staatshoofd>, JpaRepository<Staatshoofd, Long> {
    List<Staatshoofd> findByFunctie(String functie);
}
