package iii.jpaproject.vbjpa.services;

import iii.jpaproject.vbjpa.model.Inwoner;
import iii.jpaproject.vbjpa.model.Persoon;
import iii.jpaproject.vbjpa.model.Staatshoofd;
import java.util.List;

public interface IPersoonService {
    
    List<Persoon> getAllPersonen();
    
    List<Persoon> getAllPersonenByNaam(String naam); 
    
    List<Inwoner> getAllInwoners();
    
    List<Inwoner> getAllInwonersByKenmerk(String kenmerk);
    
    Inwoner getInwonerById(Long id);
    
    List<Staatshoofd> getAllStaatshoofden();
    
    List<Staatshoofd> getAllStaatshoofdenByFunctie(String functie);
    
    Staatshoofd getStaatshoofdById(Long id);

    boolean addInwoner(Inwoner i);

    boolean addStaatshoofd(Staatshoofd s);

    void deleteInwoner(Long id);

    void deleteStaatshoofd(Long id);

    void updateInwoner(Inwoner i);

    void updateStaatshoofd(Staatshoofd i);   
}
