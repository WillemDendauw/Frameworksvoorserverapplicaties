package iii.jpaproject.vbjpa;

import iii.jpaproject.vbjpa.DAO.LandenDAO;
import iii.jpaproject.vbjpa.model.Hoofdstad;
import iii.jpaproject.vbjpa.model.MyFactory;
import iii.jpaproject.vbjpa.model.Land;
import iii.jpaproject.vbjpa.model.Staatshoofd;
import iii.jpaproject.vbjpa.model.Taal;
import java.util.Arrays;
import java.util.List;
import org.hibernate.LazyInitializationException;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class LandTest {
    @Autowired
    private LandenDAO dao;  
    
    @Test
    public void contextLoads() {
    }
    
    @Test
    public void TestAddLand(){
        int size = dao.getAllLanden().size();
                
        Land l = MyFactory.maakLand("Belgie");
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelStaatshoofdInVanLand(l, s); 
        
        dao.addLand(l);
        
        assertEquals("Nieuw land toegevoegd?", size+1, dao.getAllLanden().size());
        
        dao.deleteLandById(l.getId());
    }
    
    @Test
    public void TestDeleteLand(){
        Land l = MyFactory.maakLand("Belgie");
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelStaatshoofdInVanLand(l, s);        
        Taal t1 = MyFactory.maakTaal("Arabisch");
        Taal t2 = MyFactory.maakTaal("Turks");       
        MyFactory.stelTaalInVanLand(l, t1);
        MyFactory.stelTaalInVanLand(l, t2);
        
        List<Taal> talen = Arrays.asList(t1, t2); 
        dao.addTalen(talen); 
        dao.addLand(l);
        
        int sizeLanden = dao.getAllLanden().size();
        int sizeTalen = dao.getAllTalen().size();
        int sizeStaatshoofden = dao.getAllStaatshoofden().size();
        
        dao.deleteLandById(l.getId());
        
        assertEquals("Land verwijderd?", sizeLanden - 1, dao.getAllLanden().size());
        assertEquals("Talen niet verwijderd?", sizeTalen, dao.getAllTalen().size()); //Geen Cascade
        assertEquals("Staatshoofd wel verwijderd?", sizeStaatshoofden - 1, dao.getAllStaatshoofden().size()); //Wel Cascade
        
        dao.deleteTaalById(t1.getId());
        dao.deleteTaalById(t2.getId());
    }
    
    @Test
    public void TestUpdateLand(){
        Land l = MyFactory.maakLand("Belgie");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);      
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        MyFactory.stelStaatshoofdInVanLand(l, s);
        Taal t1 = MyFactory.maakTaal("Arabisch");
        Taal t2 = MyFactory.maakTaal("Turks");       
        MyFactory.stelTaalInVanLand(l, t1);
        MyFactory.stelTaalInVanLand(l, t2);      
        List<Taal> talen = Arrays.asList(t1, t2); 
        dao.addTalen(talen); 
        dao.addLand(l);
               
        Land nieuwLand = MyFactory.maakLand("Vlaanderen");
        Hoofdstad nieuweHoofdstad = MyFactory.maakHoofdstad("Gent", 500000);
        MyFactory.stelHoofdstadInVanLand(nieuwLand, nieuweHoofdstad);
        Staatshoofd nieuwStaatshoofd = MyFactory.maakStaatshoofd("Bart", "president");
        MyFactory.stelStaatshoofdInVanLand(nieuwLand, nieuwStaatshoofd);
        Taal nieuweTaal1 = MyFactory.maakTaal("West-Vlaams");
        Taal nieuweTaal2 = MyFactory.maakTaal("Gents");
        Taal nieuweTaal3 = MyFactory.maakTaal("Antwerps");
        MyFactory.stelTaalInVanLand(nieuwLand, nieuweTaal1);
        MyFactory.stelTaalInVanLand(nieuwLand, nieuweTaal2);
        MyFactory.stelTaalInVanLand(nieuwLand, nieuweTaal3);
        List<Taal> nieuweTalen = Arrays.asList(nieuweTaal1, nieuweTaal2, nieuweTaal3);
        dao.addTalen(nieuweTalen); 
        
        dao.updateLand(l.getId(), nieuwLand);
        
        Land opgevraagd = dao.getLandById(l.getId());
        assertEquals("Nieuwe naam?", opgevraagd.getNaam(), "Vlaanderen");
        assertEquals("Nieuwe hoofdstad?", opgevraagd.getHoofdstad().getNaam_hoofdstad(), "Gent");
        assertEquals("Nieuw staatshoofd?", opgevraagd.getStaatshoofd().getNaam(), "Bart");
        
        dao.deleteLandById(l.getId());
        dao.deleteTaalById(t1.getId());
        dao.deleteTaalById(t2.getId());
        dao.deleteTaalById(nieuweTaal1.getId());
        dao.deleteTaalById(nieuweTaal2.getId());
        dao.deleteTaalById(nieuweTaal3.getId());
    }
    
    @Test
    public void TestLandEnStaatshoofdCascade(){
        int sizeLanden = dao.getAllLanden().size();
        int sizeStaatshoofden = dao.getAllStaatshoofden().size();
       
        Land l = MyFactory.maakLand("Belgie");
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelStaatshoofdInVanLand(l, s);
        
        dao.addLand(l); //Staatshoofd wordt door cascade automatisch toegevoegd        
        int sizeLanden2 = dao.getAllLanden().size();
        int sizeStaatshoofden2 = dao.getAllStaatshoofden().size();       
        assertEquals("Nieuw land toegevoegd?", sizeLanden+1, sizeLanden2);
        assertEquals("Nieuw staatshoofd toegevoegd?", sizeStaatshoofden+1, sizeStaatshoofden2);
        
        dao.deleteLandById(l.getId());
        int sizeLanden3 = dao.getAllLanden().size();
        int sizeStaatshoofden3 = dao.getAllStaatshoofden().size();
        assertEquals("Nieuw land verwijderd?", sizeLanden, sizeLanden3);
        assertEquals("Nieuw staatshoofd verwijderd?", sizeStaatshoofden, sizeStaatshoofden3);
    }
    
    @Test(expected = InvalidDataAccessApiUsageException.class)
    public void TestLandEnTaalZonderCascade(){    
        Land l = MyFactory.maakLand("Belgie");
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelStaatshoofdInVanLand(l, s);     
        Taal t1 = MyFactory.maakTaal("Arabisch");
        Taal t2 = MyFactory.maakTaal("Turks");       
        MyFactory.stelTaalInVanLand(l, t1);
        MyFactory.stelTaalInVanLand(l, t2);
               
        dao.addLand(l); //Gooit exceptie op want t1 en t2 nooit toegevoegd aan de database omdat er hier geen gebruik gemaakt werd van cascade 
        
        dao.deleteLandById(l.getId());
    }
    
    @Test(expected = LazyInitializationException.class)
    public void TestLazyFetchingTalen(){
        Land l = MyFactory.maakLand("Belgie");
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelStaatshoofdInVanLand(l, s);     
        Taal t1 = MyFactory.maakTaal("Arabisch");
        Taal t2 = MyFactory.maakTaal("Turks");       
        MyFactory.stelTaalInVanLand(l, t1);
        MyFactory.stelTaalInVanLand(l, t2);
        
        List<Taal> talen = Arrays.asList(t1, t2); 
        dao.addTalen(talen); //Datalaag kan een willekeurige collectie van talen toevoegen
        dao.addLand(l);
        
        Land gevondenLand = dao.getAllLandenByNaam("Belgie").get(0);
        dao.deleteLandById(l.getId());
        dao.deleteTaalById(t1.getId());
        dao.deleteTaalById(t2.getId());
        gevondenLand.getTalen().size(); //Gooit exceptie op want Lazy fetching: talen niet mee opgevraagd
    }
    
    @Test
    public void TestNietLazyFetchingStaatshoofd(){
        Land l = MyFactory.maakLand("Belgie");
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelStaatshoofdInVanLand(l, s);     
        Taal t1 = MyFactory.maakTaal("Arabisch");
        Taal t2 = MyFactory.maakTaal("Turks");       
        MyFactory.stelTaalInVanLand(l, t1);
        MyFactory.stelTaalInVanLand(l, t2);
        
        List<Taal> talen = Arrays.asList(t1, t2); 
        dao.addTalen(talen); 
        dao.addLand(l);
        
        Land gevondenLand = dao.getAllLandenByNaam("Belgie").get(0); //Niet-lazy fetching: staatshoofd van gevondenLand mee opgevraagd
        assertEquals("Staatshoofd mee opgevraagd?", gevondenLand.getStaatshoofd().getNaam(), "Filip");
        
        dao.deleteLandById(l.getId());
        dao.deleteTaalById(t1.getId());
        dao.deleteTaalById(t2.getId());
    }   
    
    @Test
    public void TestEmbeddedHoofdstad(){
        Land l = MyFactory.maakLand("Belgie");
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelStaatshoofdInVanLand(l, s);        
        dao.addLand(l);
        
        Land gevondenLand = dao.getAllLandenByNaam("Belgie").get(0); 
        assertEquals("Hoofdstad naam correct?", gevondenLand.getHoofdstad().getNaam_hoofdstad(), "Brussel");
        assertEquals("Hoofdstad bevolking correct?", gevondenLand.getHoofdstad().getBevolkingsaantal_hoofdstad(), 2000000);
        dao.deleteLandById(l.getId());
    }
}
