package iii.jpaproject.vbjpa;

import iii.jpaproject.vbjpa.DAO.LandenDAO;
import iii.jpaproject.vbjpa.model.Hoofdstad;
import iii.jpaproject.vbjpa.model.Land;
import iii.jpaproject.vbjpa.model.MyFactory;
import iii.jpaproject.vbjpa.model.Taal;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TaalTest {
    @Autowired
    private LandenDAO dao;  
    
    @Test
    public void contextLoads() {
    }
    
    @Test
    public void TestAddTalen(){
        int size = dao.getAllTalen().size();
        Taal t1 = MyFactory.maakTaal("Arabisch");
        Taal t2 = MyFactory.maakTaal("Turks");  
        Taal t3 = MyFactory.maakTaal("Chinees");    
        List<Taal> talen = Arrays.asList(t1, t2, t3); 
        
        dao.addTalen(talen); //Collectie toevoegen
        int size_nieuw = dao.getAllTalen().size();
        
        assertEquals("Nieuwe talen toegevoegd?", size+talen.size(), size_nieuw);
        for(Taal t : talen){
            dao.deleteTaalById(t.getId());
        }    
    }
    
    @Test
    public void TestDeleteTaal(){       
        Taal tg = MyFactory.maakTaal("Grieks");
        Taal tt = MyFactory.maakTaal("Turks");
        
        Land lc = MyFactory.maakLand("Cyprus");
        Hoofdstad hc = MyFactory.maakHoofdstad("Nikosia", 50000);
        MyFactory.stelHoofdstadInVanLand(lc, hc);
        Land lt = MyFactory.maakLand("Turkije");
        Hoofdstad ht = MyFactory.maakHoofdstad("Ankara", 1000000);
        MyFactory.stelHoofdstadInVanLand(lt, ht);
        
        MyFactory.stelTaalInVanLand(lc, tg);
        MyFactory.stelTaalInVanLand(lc, tt);      
        MyFactory.stelTaalInVanLand(lt, tg);
               
        List<Taal> talenCyprus = Arrays.asList(tg, tt); 
        dao.addTalen(talenCyprus); 
        dao.addTaal(tt);
        dao.addLand(lc);
        dao.addLand(lt);
        
        int sizeLanden = dao.getAllLanden().size();
        int sizeTalen = dao.getAllTalen().size();
        
        dao.deleteLandById(lc.getId());
        dao.deleteLandById(lt.getId());
        assertEquals("Landen verwijderd?", sizeLanden - 2, dao.getAllLanden().size()); 
        
        dao.deleteTaalById(tt.getId());
        dao.deleteTaalById(tg.getId());
        assertEquals("Talen verwijderd?", sizeTalen - 2, dao.getAllTalen().size());   
    }
    
    @Test
    public void TestUpdateTaal(){ 
        Taal t = MyFactory.maakTaal("Chinees");
        Taal nieuweTaal = MyFactory.maakTaal("Japans");
        
        dao.addTaal(t);
        dao.updateTaal(t.getId(), nieuweTaal);
        
        Taal opgevraagd = dao.getTaalByID(t.getId());
        assertEquals("Taal aangepast?", opgevraagd.getNaam(), "Japans");
        
        dao.deleteTaalById(t.getId());
    }   
    
    @Test
    public void TestNietLazyFetchingLanden(){
        Land l1 = MyFactory.maakLand("Belgie");
        Hoofdstad h1 = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l1, h1);
        Land l2 = MyFactory.maakLand("Nederland");   
        Hoofdstad h2 = MyFactory.maakHoofdstad("Amsterdam", 3000000);
        MyFactory.stelHoofdstadInVanLand(l2, h2);
        Taal t = MyFactory.maakTaal("Chinees");
        MyFactory.stelTaalInVanLand(l1, t);
        MyFactory.stelTaalInVanLand(l2, t);
        
        dao.addTaal(t);
        dao.addLand(l1);
        dao.addLand(l2);  
        
        Taal opgevraagd = dao.getTaalByID(t.getId());
        assertEquals("Landen mee?", opgevraagd.getLanden().size(), 2);
        
        dao.deleteLandById(l1.getId());
        dao.deleteLandById(l2.getId());
        dao.deleteTaalById(t.getId());
    }
}
