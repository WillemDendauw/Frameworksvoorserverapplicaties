package iii.jpaproject.vbjpa;

import iii.jpaproject.vbjpa.DAO.LandenDAO;
import iii.jpaproject.vbjpa.model.Hoofdstad;
import iii.jpaproject.vbjpa.model.MyFactory;
import iii.jpaproject.vbjpa.model.Land;
import iii.jpaproject.vbjpa.model.Staatshoofd;
import java.util.List;
import org.hibernate.LazyInitializationException;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StaatshoofdTest {
    @Autowired
    private LandenDAO dao;  
    
    @Test
    public void contextLoads() {
    }
    
    @Test
    public void TestGetAllStaatshoofdenByFunctie(){
        Staatshoofd s1 = MyFactory.maakStaatshoofd("Filip", "koning");
        Land l1 = MyFactory.maakLand("Belgie");
        Hoofdstad h1 = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l1, h1);
        MyFactory.stelStaatshoofdInVanLand(l1, s1);
        
        Staatshoofd s2 = MyFactory.maakStaatshoofd("Albert", "koning");
        Land l2 = MyFactory.maakLand("Belgie2");
        Hoofdstad h2 = MyFactory.maakHoofdstad("Brusse2l", 2000000);
        MyFactory.stelHoofdstadInVanLand(l2, h2);
        MyFactory.stelStaatshoofdInVanLand(l2, s2);
        
        Staatshoofd s3 = MyFactory.maakStaatshoofd("Leopold", "koning");
        Land l3 = MyFactory.maakLand("Belgie3");
        Hoofdstad h3 = MyFactory.maakHoofdstad("Brussel3", 2000000);
        MyFactory.stelHoofdstadInVanLand(l3, h3);
        MyFactory.stelStaatshoofdInVanLand(l3, s3);
        
        Staatshoofd s4 = MyFactory.maakStaatshoofd("Barack", "president");
        Land l4 = MyFactory.maakLand("USA");
        Hoofdstad h4 = MyFactory.maakHoofdstad("Washington", 2000000);
        MyFactory.stelHoofdstadInVanLand(l4, h4);
        MyFactory.stelStaatshoofdInVanLand(l4, s4);
        
        dao.addLand(l1);
        dao.addLand(l2);
        dao.addLand(l3);
        dao.addLand(l4);
        
        List<Staatshoofd> koningen = dao.getAllStaatshoofdenByFunctie("koning");
        
        assertEquals("3 koningen?", koningen.size(), 3);
        
        dao.deleteLandById(l1.getId());
        dao.deleteLandById(l2.getId());
        dao.deleteLandById(l3.getId());
        dao.deleteLandById(l4.getId());
    }
    
    @Test
    public void TestAddStaatshoofd(){
        int size = dao.getAllStaatshoofden().size();
                
        Staatshoofd s1 = MyFactory.maakStaatshoofd("Filip", "koning");
        Land l1 = MyFactory.maakLand("Belgie");
        Hoofdstad h1 = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l1, h1);
        MyFactory.stelStaatshoofdInVanLand(l1, s1);
        
        Staatshoofd s2 = MyFactory.maakStaatshoofd("Albert", "koning");
        Land l2 = MyFactory.maakLand("Belgie2");
        Hoofdstad h2 = MyFactory.maakHoofdstad("Brusse2l", 2000000);
        MyFactory.stelHoofdstadInVanLand(l2, h2);
        MyFactory.stelStaatshoofdInVanLand(l2, s2);
        
        dao.addLand(l1); //Door cascade staatshoofden ook toegevoegd
        dao.addLand(l2);
        int size2 = dao.getAllStaatshoofden().size();
        
        assertEquals("Staatshoofden toegevoegd?", size+2, size2);
        
        dao.deleteLandById(l1.getId());
        dao.deleteLandById(l2.getId());
    }
    
    @Test
    public void TestDeleteStaatshoofd(){
        Staatshoofd s1 = MyFactory.maakStaatshoofd("Filip", "koning");
        Land l1 = MyFactory.maakLand("Belgie");
        Hoofdstad h1 = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l1, h1);
        MyFactory.stelStaatshoofdInVanLand(l1, s1);
        
        Staatshoofd s2 = MyFactory.maakStaatshoofd("Albert", "koning");
        Land l2 = MyFactory.maakLand("Belgie2");
        Hoofdstad h2 = MyFactory.maakHoofdstad("Brusse2l", 2000000);
        MyFactory.stelHoofdstadInVanLand(l2, h2);
        MyFactory.stelStaatshoofdInVanLand(l2, s2);
        
        dao.addLand(l1);
        dao.addLand(l2);
        
        int size_staatshoofden = dao.getAllStaatshoofden().size();
        
        dao.deleteLandById(l1.getId()); //Door cascade staatshoofden ook verwijderd
        dao.deleteLandById(l2.getId());
        
        assertEquals("Staatshoofden verwijderd?", size_staatshoofden-2, dao.getAllStaatshoofden().size());
    }
    
    @Test
    public void TestUpdateStaatshoofd(){
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        Land l = MyFactory.maakLand("Belgie");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelStaatshoofdInVanLand(l, s);
        
        Staatshoofd nieuwStaatshoofd = MyFactory.maakStaatshoofd("Barack", "president");
        Land nieuwLand = MyFactory.maakLand("USA");
        Hoofdstad nieuweHoofdstad = MyFactory.maakHoofdstad("Washington", 10000000);
        MyFactory.stelHoofdstadInVanLand(nieuwLand, nieuweHoofdstad);
        MyFactory.stelStaatshoofdInVanLand(nieuwLand, nieuwStaatshoofd);
        
        dao.addLand(l);
        dao.addLand(nieuwLand);
        dao.updateStaatshoofd(s.getId(), nieuwStaatshoofd);
        
        Staatshoofd opgevraagd = dao.getStaatshoofdById(s.getId());
        assertEquals("Naam aangepast?", opgevraagd.getNaam(), "Barack");
        assertEquals("Functie aangepast?", opgevraagd.getFunctie(), "president");
        
        dao.deleteLandById(l.getId());
        dao.deleteLandById(nieuwLand.getId());
    }
    
    @Test(expected = LazyInitializationException.class)
    public void TestLazyFetchingLand(){
        Staatshoofd s = MyFactory.maakStaatshoofd("Filip", "koning");
        Land l = MyFactory.maakLand("Belgie");    
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelStaatshoofdInVanLand(l, s); 
        
        dao.addLand(l);
        
        Staatshoofd opgevraagd = dao.getStaatshoofdById(s.getId());
        dao.deleteLandById(l.getId());
        
        opgevraagd.getLand().getNaam(); //Gooit exceptie op want land niet mee opgevraagd: lazy fetching
    }
}