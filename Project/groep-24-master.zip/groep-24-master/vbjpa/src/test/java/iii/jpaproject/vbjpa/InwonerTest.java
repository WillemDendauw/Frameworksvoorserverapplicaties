package iii.jpaproject.vbjpa;

import iii.jpaproject.vbjpa.DAO.LandenDAO;
import iii.jpaproject.vbjpa.model.Hoofdstad;
import iii.jpaproject.vbjpa.model.Inwoner;
import iii.jpaproject.vbjpa.model.MyFactory;
import iii.jpaproject.vbjpa.model.Land;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class InwonerTest {
    @Autowired
    private LandenDAO dao;  
    
    @Test
    public void contextLoads() {
    }
    
    @Test
    public void TestGetAllInwonersByKenmerk(){
        Inwoner i1 = MyFactory.maakInwoner("Tom", "voetballer");
        Inwoner i2 = MyFactory.maakInwoner("Tim", "voetballer");
        Inwoner i3 = MyFactory.maakInwoner("Thomas", "wielrenner");
        Inwoner i4 = MyFactory.maakInwoner("Steven", "voetballer");
        
        List<Inwoner> inwoners = Arrays.asList(i1, i2, i3, i4); 
        dao.addInwoners(inwoners); //Datalaag kan verzameling van inwoners toevoegen
        
        List<Inwoner> voetballers = dao.getAllInwonersByKenmerk("voetballer");
        
        assertEquals("3 voetballers?", voetballers.size(), 3);
        
        for(Inwoner i : inwoners){
            dao.deleteInwonerById(i.getId());
        } 
    }
    
    @Test
    public void TestAddInwoner(){
        int size = dao.getAllInwoners().size();
        Inwoner i1 = MyFactory.maakInwoner("Tom", "voetballer");
        Inwoner i2 = MyFactory.maakInwoner("Tim", "voetballer");
        Inwoner i3 = MyFactory.maakInwoner("Thomas", "wielrenner");    
        List<Inwoner> inwoners = Arrays.asList(i1, i2, i3); 
        
        dao.addInwoners(inwoners); //Datalaag kan verzameling van inwoners toevoegen
        int size_nieuw = dao.getAllInwoners().size();
        
        assertEquals("Nieuwe inwoners toegevoegd?", size+inwoners.size(), size_nieuw);
        for(Inwoner i : inwoners){
            dao.deleteInwonerById(i.getId());
        }  
    }
    
    @Test
    public void TestDeleteInwoner(){
        Land l = MyFactory.maakLand("Belgie");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);      
        Inwoner i1 = MyFactory.maakInwoner("Tom", "voetballer");
        Inwoner i2 = MyFactory.maakInwoner("Tim", "voetballer");
        Inwoner i3 = MyFactory.maakInwoner("Thomas", "wielrenner"); 
        MyFactory.stelLandInVanInwoner(l, i1);
        MyFactory.stelLandInVanInwoner(l, i2);
        MyFactory.stelLandInVanInwoner(l, i3);
        
        dao.addLand(l);
        dao.addInwoner(i1);
        dao.addInwoner(i2);
        dao.addInwoner(i3);
        
        int size_inwoners = dao.getAllInwoners().size();
        int size_landen = dao.getAllLanden().size();
        
        dao.deleteInwonerById(i1.getId());
        dao.deleteInwonerById(i2.getId());
        dao.deleteInwonerById(i3.getId());
        
        int size_inwoners2 = dao.getAllInwoners().size();
        int size_landen2 = dao.getAllLanden().size();
        
        assertEquals("Nieuwe inwoners verwijderd?", size_inwoners - 3, size_inwoners2);
        assertEquals("Geen land verwijderd?", size_landen, size_landen2); //Geen cascade
        
        dao.deleteLandById(l.getId());
    }
    
    @Test
    public void TestUpdateInwoner(){
        Inwoner i = MyFactory.maakInwoner("Tom", "voetballer");
        Land l = MyFactory.maakLand("Belgie");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelLandInVanInwoner(l, i);
        
        Inwoner nieuweInwoner = MyFactory.maakInwoner("Tim", "wielrenner");
        Land nieuwLand = MyFactory.maakLand("Nederland");
        Hoofdstad nieuweHoofdstad = MyFactory.maakHoofdstad("Amsterdam", 3000000);
        MyFactory.stelHoofdstadInVanLand(nieuwLand, nieuweHoofdstad);
        MyFactory.stelLandInVanInwoner(nieuwLand, nieuweInwoner);
        
        dao.addLand(l);
        dao.addLand(nieuwLand);
        dao.addInwoner(i);
        dao.updateInwoner(i.getId(), nieuweInwoner);
        
        Inwoner opgevraagd = dao.getInwonerById(i.getId());
        assertEquals("Naam aangepast?", opgevraagd.getNaam(), "Tim");
        assertEquals("Kenmerk aangepast?", opgevraagd.getKenmerk(), "wielrenner");
        assertEquals("Land aangepast?", opgevraagd.getLand().getNaam(), "Nederland");
        
        dao.deleteInwonerById(i.getId());
        dao.deleteLandById(l.getId());
        dao.deleteLandById(nieuwLand.getId());
    }
    
    @Test
    public void TestNietLazyFetchingLand(){
        Inwoner i = MyFactory.maakInwoner("Tom", "voetballer");
        Land l = MyFactory.maakLand("Belgie");
        Hoofdstad h = MyFactory.maakHoofdstad("Brussel", 2000000);
        MyFactory.stelHoofdstadInVanLand(l, h);
        MyFactory.stelLandInVanInwoner(l, i);
        
        dao.addLand(l);
        dao.addInwoner(i);
        
        Inwoner opgevraagd = dao.getInwonerById(i.getId());
        
        assertEquals("Land mee opgevraagd?", opgevraagd.getLand().getNaam(), "Belgie"); //Eager fetching
        
        dao.deleteInwonerById(i.getId());
        dao.deleteLandById(l.getId());
    }
}
