# groep-24
De tabelstructuur wordt automatisch aangemaakt bij een eerste keer runnen van het project.<br>
In de test package zitten 4 testfiles: InwonerTest, LandTest, StaatshoofdTest en TaalTest.<br>
De testen worden uitgevoerd op een oorspronkelijk lege databank.
Op het einde van iedere test worden eventueel toegevoegde rijen verwijderd zodat de databank niet permanent aangepast wordt.
